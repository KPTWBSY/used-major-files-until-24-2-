from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *

vertices = ((-1.0,-1.0,-1.0),(1.0,-1.0,-1.0),
            (1.0,1.0,-1.0), (-1.0,1.0,-1.0), (-1.0,-1.0,1.0),
            (1.0,-1.0,1.0), (1.0,1.0,1.0), (-1.0,1.0,1.0))

colors = ((0.0,0.0,0.0),(1.0,0.0,0.0),
          (1.0,1.0,0.0), (0.0,1.0,0.0), (0.0,0.0,1.0),
          (1.0,0.0,1.0), (1.0,1.0,1.0), (0.0,1.0,1.0))

xRot = 30.0
yRot = 30.0

def polygon( a, b, c , d):
	glBegin(GL_POLYGON)
	glColor3fv(colors[a])
	glVertex3fv(vertices[a])
	glColor3fv(colors[b])
	glVertex3fv(vertices[b])
	glColor3fv(colors[c])
	glVertex3fv(vertices[c])
	glColor3fv(colors[d])
	glVertex3fv(vertices[d])
	glEnd()

def colorcube():
	polygon( 0,1,2,3)
	polygon(0,1,5,4)
	polygon( 4,5,6,7)
	polygon( 5,1,2,6)
	polygon(6,2,3,7)
	polygon( 4,7,3,0)
    #1) 정의된 정육면체를 보여주기 위한 폴리곤 생성.

def MyDisplay():
    global myview
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()
    gluLookAt(3.0, 3.0, 3.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0)
    #2) 큐브를 x축으로 45도 회전하게 하는 코드.
    #glRotatef(45, 1, 0, 0)

    #3) 큐브를 z축으로 45도 회전하게 하는 코드.
    #glRotatef(45, 0, 0, 1)

    colorcube()
    glutSwapBuffers()

def myReshape(w, h):
    glViewport(0, 0, w, h)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    # glFrustum (left, right, bottom, top, near distance, far distance)
    if w <= h:
        glFrustum(-2.0, 2.0, -2.0 * float(h)/ float(w), 2.0* float(h) / float(w), 2.0, 20.0)
    else:
        glFrustum(-2.0, 2.0, -2.0 * float(w)/ float(h), 2.0* float(w) / float(h), 2.0, 20.0)
    glMatrixMode(GL_MODELVIEW)


def main():
    glutInit(sys.argv)
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH)
    glutInitWindowSize(500, 500)
    glutCreateWindow('color cube')
    glutReshapeFunc(myReshape)
    glutDisplayFunc(MyDisplay)

    glutAttachMenu(GLUT_RIGHT_BUTTON)

    glEnable(GL_DEPTH_TEST)
    glutMainLoop()

if __name__ == "__main__":
    main()