from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *

def MyDisplay():
  glClear(GL_COLOR_BUFFER_BIT)
  glColor3f(0.75, 0.0, 1.0)
  glutSolidSphere(0.75,20,20)
  glFlush()

def main():
  glutInit(sys.argv)
  glutCreateWindow('Hello OpenGL!')
  glClearColor(0.0,0.0,0.0,1.0)
  glutDisplayFunc(MyDisplay)
  glutMainLoop()

if __name__ == '__main__':
 main()
