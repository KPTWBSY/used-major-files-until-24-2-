class Fraction:
    def __init__(self,up=1,down=1):
        self.num=up
        self.den=down
        
    def __str__(self):
        return str(self.num)+"/"+str(self.den)
    
    def gcd(self,a,b):
        while a%b!=0:
            a,b=b,a%b
        return b
  
    def abbrevitation(self):
        common=self.gcd(self.num,self.den)
        if self.num>self.den and common==self.den:
            return self.num/common
        else:
            return Fraction(int(self.num//common),int(self.den//common))

    def Decimal_fraction(self,real):
        x=1
        while True:
            if real*10%1==0:
               self.num=int(real*10)
               self.den=10**x 
               return self 
            else:
                real=real*10
                x+=1
                
num2=Fraction()

decimal_number=float(input("실수를 입력하세요 "))
num2.Decimal_fraction(decimal_number)
print("분수 표현 : ",num2.abbrevitation())