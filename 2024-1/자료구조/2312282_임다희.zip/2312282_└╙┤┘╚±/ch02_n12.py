Score1=[]
total=i=0
while True:
    score=input("%d번째 프레임 : "%(i+1))
    score=list(int(x) for x in score.split(","))
    point1,point2=score[0],score[1]

    if (point1+point2>10) and (i!=10):
            print("다시 입력해 주세요")

    else:
        if (point1,point2)==(10,0):
            score.append('~')
            score.append(point1+point2)
        elif(point1+point2)==10 and (point1,point2)!=(10,0):
            score.append('/')
            score.append(point1+point2)
        else:
            score.append('-')
            score.append(point1+point2)
        Score1.append(tuple(score))
        print(Score1)
        
        total+=point1+point2
        if i>=1:
            prev_point1,prev_point2=Score1[i-1][0],Score1[i-1][1]

            if (prev_point1, prev_point2)==(10,0):       
                if i>1:
                    prev_prev_point1,prev_prev_point2=Score1[i-2][0],Score1[i-2][1]
                    if (prev_prev_point1,prev_prev_point2)==(10,0):
                        total+=point1*2+point2
                        if i==10:
                            total-=(point1+point2)
                    
                    else:
                        total+=point1+point2
                        if i==10:
                            total-=(point1)
                else:
                        total+=point1+point2
            elif (prev_point1+prev_point2==10) and ((prev_point1,prev_point2)!=(10,0)) :
                    total+=point1
                
                    
        print("Total : ", total)
            
        i+=1
    if i==10 and ((point1+point2)!=10):
        break
    elif i==11:
        break
    