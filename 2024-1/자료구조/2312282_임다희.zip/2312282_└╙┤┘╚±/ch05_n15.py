#저장본 4 

class Node:
    def __init__(self,item):
        self.data=item
        self.rlink=None
        self.llink=None

class LinkedList:
    def __init__(self):
        self.head=None
        self.tail=None

    def isEmpty(self):
        return not self.head
    
    def add_rear(self,item):
        node=Node(item)
        if not self.head:
            self.head=node
            self.tail=node
        else:
            self.tail.rlink=node
            node.llink=self.tail
            self.tail=node
            node.rlink=self.head
            self.head.llink=node

    def view(self):
        temp=self.head
        print("[",end=' ')
        while True:
            print(temp.data,end=' ')
            temp=temp.rlink
            if temp==self.head:
                break
        print("]",end=' ')
    
    def find(self,item):
        temp=self.head
        while True:
            if temp.data==item: return temp
            temp=temp.rlink
            if temp==self.head: break
        return None
        
    def change(self):
        node=self.find(1)
        another=self.find(2)
        if node or another==None:
            return False
        else:
            node.data=2
            another.data=1
		
    def Move(self,item,num,to):
        node=self.find(item)
        if not node:
            print("Not found")
            return False
        if node:
            if to==1:
                temp=node.rlink
                for a in range(num-1):
                    newtemp=temp
                    temp=newtemp.rlink
               
                temp.data=node.data
                node.data=0

            elif to==-1:
                temp=node.llink
                for a in range(num-1):
                    newtemp=temp
                    temp=newtemp.llink
                
                temp.data=node.data
                node.data=0
                
        

lst=LinkedList()
x=int(input("노드 수 입력"))
lst.add_rear(1)
for y in range(x//2-1):
    lst.add_rear(0)
lst.add_rear(2)
for y in range(x//2-1):
    lst.add_rear(0)

print("플레이어 초기 위치")
lst.view()

def player1():
    global x
    import random
    num1=random.randint(1,6)
    num2=random.randint(1,6)
   
    if lst.find(1)==None:
        print("\n 플레이어 2 승리")
        return False
    else:
        if (num1,num2)==(6,6):
            if x==1: x=-1
            elif x==-1:x=1
            print("\n 1",(num1,num2),"방향 변경")

        elif (num1,num2)==(5,5):
            print("\n 1",(num1,num2),"자리 변경")
            lst.change()
            lst.view()
        else:
            print("\n 1",(num1,num2),"%d칸 전진"%(num1+num2))
            a=lst.Move(1,int(num1+num2),x)
            if a==False: return False
            lst.view()
         
def player2():
    global x
    import random
    num1=random.randint(1,6)
    num2=random.randint(1,6)

    if lst.find(2)==None:
        print("\n 플레이어 1 승리")
        return False   
    else:
    
        if (num1,num2)==(6,6):
            if x==1: x=-1
            elif x==-1:x=1
            print("\n 2",(num1,num2),"방향 변경")

        elif (num1,num2)==(5,5):
            print("\n 2",(num1,num2),"자리 변경")
            lst.change()
            lst.view()

        else:
            print("\n 2",(num1,num2),"%d칸 전진"%(num1+num2))
            a=lst.Move(2,int(num1+num2),x)
            if a==False: return False
            lst.view()
        
x=1
while True:

    if player1()==False:
        break
    if player2()==False:
        break