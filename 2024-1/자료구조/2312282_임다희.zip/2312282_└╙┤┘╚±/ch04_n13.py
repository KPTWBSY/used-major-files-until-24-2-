class Sym:
    OPEN_B=1
    CLOSE_B=2
    PLUS=3
    MINUS=4
    TIMES=5
    DIVIDE=6
    MOD=7
    OPERAND=8
class Expression:
    def __init__(self,expr):
        self.stack1=[]
        self.stack2=[]
        self.stack3=[]
        self.size=100
        self.expr=expr 
        self.top=-1
        self.output=""

    def isEmpty(self,which):
        return len(which)==0
    def isFull(self,which):
        return len(which)==self.size
    def show_stack(self,which):
        print(which)

    def push(self,item,which):
        if not self.isFull(which):
            self.top+=1
            which.append(item)
            self.show_stack(which)
        else:
            print("Stack full")
    def pop(self,which):
        if not self.isEmpty(which):
            self.top-=1
            return which.pop()
        else:
            print("Stack empty")
    
    def eval_postfix(self):

        for sym in self.expr:
            sym_type=self.getSymtype(sym)
            if sym_type== Sym.OPERAND:
                self.push(int(sym),self.stack3)
            else:
                print("evaulation : ",self.stack3[-2],self.stack3[-1],sym)

                op2=self.pop(self.stack3)
                op1=self.pop(self.stack3)
                if sym_type==Sym.PLUS:
                    self.push(op1+op2,self.stack3)
                elif sym_type==Sym.MINUS:
                    self.push(op1-op2,self.stack3)
                elif sym_type==Sym.TIMES:
                    self.push(op1*op2,self.stack3)
                elif sym_type==Sym.DIVIDE:
                    self.push(op1/op2,self.stack3)
                elif sym_type==Sym.MOD:
                    self.push(op1%op2,self.stack3)
        return self.pop(self.stack3)
    
    def infix_postfix(self):
        for token in expr.split():
            if token.isalnum():
                self.push(token,self.stack1)
            elif token=='(':
                self.push(token,self.stack2)
            elif token==')':
                sym=self.pop(self.stack2)
                while sym!='(':
                    self.push(sym,self.stack1)
                    sym=self.pop(self.stack2)

            else:
                while not self.isEmpty(self.stack2) and self.precedence(self.stack2[-1])>=self.precedence(token):
                    sym=self.pop(self.stack2)
                    self.push(sym,self.stack1)
                self.push(token,self.stack2)
        while not self.isEmpty(self.stack2):
            self.push(self.pop(self.stack2),self.stack1)
        self.output=self.stack1

    
    def precedence(self,op):
        if op=='(': return 0
        elif op in ['+','-']: return 1
        elif op in ['*','/','%']:return 2

    def getSymtype(self,sym):
        if sym=='(':sym_type=Sym.OPEN_B
        elif sym==')':sym_type=Sym.CLOSE_B
        elif sym=='+':sym_type=Sym.PLUS
        elif sym=='-':sym_type=Sym.MINUS
        elif sym=='*':sym_type=Sym.TIMES
        elif sym=='/':sym_type=Sym.DIVIDE
        elif sym=='%':sym_type=Sym.MOD
        else: sym_type=Sym.OPERAND
        return sym_type

expr=input("input an infix :")
e=Expression(expr)
print()
e.infix_postfix()
print("postfix : ",e.output)
e.expr=e.output
print()
print("evaluation : ",e.eval_postfix())