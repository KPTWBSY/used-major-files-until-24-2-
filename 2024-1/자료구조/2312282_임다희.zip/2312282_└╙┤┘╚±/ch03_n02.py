def find(lst):
    if len(lst)==1:
        return (lst[0],lst[0])
    elif len(lst)==2:
        if lst[0]<lst[1]:
            return (lst[0],lst[1])
        elif lst[0]>lst[1]:
            return(lst[1],lst[0])
        else:
            return(lst[0],lst[0])
    else:
        mid=len(lst)//2
        min_left,max_left=find(lst[:mid])
        min_right,max_right=find(lst[mid:])

        a=b=0
        if min_left>=min_right:
            a=min_right
        else:
            a=min_left
        if max_left>=max_right:
            b=max_left
        else:
            b=max_right
        return a,b
             

my_lst=[3,7,2,9,1,5]
min_val,max_val=find(my_lst)

print(my_lst)
print("최소값: ",min_val)
print("최대값: ",max_val)